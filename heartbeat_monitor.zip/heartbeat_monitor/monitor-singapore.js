// heartbeat-monitor.js
// Heartbeat tester that logs all results to a file.

import fs from "fs";
import path from "path";
import fetch from "node-fetch";

const CONFIG = {
  baseUrl: "https://api.drop-shot.live",
  groundId: "385136f6-7cf0-4e7f-b601-fea90079c227",
  intervalMs: 30_000,
  timeoutMs: 15_000,
  logDir: "./logs",
  logFile: "heartbeat.log",
  region: "Singapore"
};

// // Ensure logs directory exists
// if (!fs.existsSync(CONFIG.logDir)) {
//   fs.mkdirSync(CONFIG.logDir, { recursive: true });
// }

// const logPath = path.join(CONFIG.logDir, CONFIG.logFile);

// // Create a write stream for logs
// const logStream = fs.createWriteStream(logPath, {
//   flags: "a",
//   encoding: "utf8"
// });

function writeLog(message) {
  const line = `[${CONFIG.region}] [${new Date().toLocaleString('en-US', { timeZone: 'Asia/Karachi', hour12: true })}] ${message}`;
  console.log(line);
}

async function sendHeartbeat() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), CONFIG.timeoutMs);

  const url = `${CONFIG.baseUrl}/api/v1/padel-grounds/heartbeat`;

  try {
    const startTime = Date.now()
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "accept": "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ groundId: CONFIG.groundId }),
      signal: controller.signal
    });
    const responseMs = Date.now() - startTime

    clearTimeout(timeout);

    if (!response.ok) {
      const text = await response.text().catch(() => "");
      throw new Error(`HTTP ${response.status}: ${response.statusText} - ${text}`);
    }

    return { success: true, status: response.status, responseMs };
  } catch (err) {
    clearTimeout(timeout);

    if (err.name === "AbortError") {
      return { success: false, error: "Request timed out" };
    }

    return { success: false, error: err.message || String(err) };
  }
}

async function startMonitoring() {
  writeLog("Heartbeat monitor started.");

  while (true) {
    const result = await sendHeartbeat();

    if (result.success) {
      writeLog(`OK   | HTTP ${result.status} | ${result.responseMs} ms`);
    } else {
      writeLog(`FAIL | ${result.error}`);
    }

    await new Promise(r => setTimeout(r, CONFIG.intervalMs));
  }
}

startMonitoring();
